<?php if(count($detailResponden) > 0): ?>
    <div class="overflow-x-auto">
        <table class="w-full text-xs">
            <thead class="text-gray-500 border-b border-gray-100 bg-gray-50">
                <tr>
                    <th class="text-left font-semibold px-3 py-3 whitespace-nowrap">NIP</th>
                    <th class="text-left font-semibold px-3 py-3 whitespace-nowrap">Nama</th>
                    <th class="text-left font-semibold px-3 py-3 whitespace-nowrap">Pusat Riset</th>
                    <th class="text-left font-semibold px-3 py-3 whitespace-nowrap">Posisi</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">Kelamin</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">Usia</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">Lama Kerja</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">Mode Kerja</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">I. Kebijakan</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">II. Motivasi</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">III. Kepuasan</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">IV. Engagement</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">V. Stres</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">VI. Dukungan</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">VII. WLB</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">Rata-rata</th>
                    <th class="text-center font-semibold px-3 py-3 whitespace-nowrap">Tgl Submit</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__currentLoopData = $detailResponden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-3 py-3 font-mono text-gray-600 whitespace-nowrap"><?php echo e($row['nip']); ?></td>
                        <td class="px-3 py-3 font-semibold text-gray-800 whitespace-nowrap"><?php echo e($row['nama']); ?></td>
                        <td class="px-3 py-3 text-gray-600 whitespace-nowrap max-w-[160px] truncate" title="<?php echo e($row['pusat_riset']); ?>"><?php echo e($row['pusat_riset']); ?></td>
                        <td class="px-3 py-3 text-gray-600 whitespace-nowrap"><?php echo e($row['posisi']); ?></td>
                        <td class="px-3 py-3 text-center text-gray-600"><?php echo e($row['jenis_kelamin']); ?></td>
                        <td class="px-3 py-3 text-center text-gray-600 whitespace-nowrap"><?php echo e($row['usia']); ?></td>
                        <td class="px-3 py-3 text-center text-gray-600 whitespace-nowrap"><?php echo e($row['lama_bekerja']); ?></td>
                        <td class="px-3 py-3 text-center">
                            <span class="inline-flex px-2 py-0.5 rounded-full text-xs font-semibold
                                <?php echo e($row['mode_kerja'] === 'WFA' ? 'bg-blue-100 text-blue-700' : ($row['mode_kerja'] === 'WFO' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700')); ?>">
                                <?php echo e($row['mode_kerja']); ?>

                            </span>
                        </td>
                        <?php $__currentLoopData = $row['per_kategori']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="px-3 py-3 text-center">
                                <?php if($skor !== '-'): ?>
                                    <span class="font-semibold <?php echo e((float)$skor >= 4.0 ? 'text-emerald-600' : ((float)$skor >= 3.0 ? 'text-amber-600' : 'text-red-500')); ?>">
                                        <?php echo e($skor); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-gray-300">-</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-3 py-3 text-center font-bold text-gray-800"><?php echo e($row['rata_rata']); ?></td>
                        <td class="px-3 py-3 text-center text-gray-500 whitespace-nowrap"><?php echo e($row['submitted_at']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <p class="text-xs text-gray-400 mt-4">Menampilkan <?php echo e(count($detailResponden)); ?> responden sesuai filter aktif.</p>
<?php else: ?>
    <div class="text-center py-12">
        <span class="inline-flex items-center justify-center w-14 h-14 rounded-full bg-gray-50 text-gray-300 mb-4">
            <i data-lucide="inbox" class="w-6 h-6"></i>
        </span>
        <p class="text-sm font-semibold text-gray-500">Belum ada data responden</p>
        <p class="text-xs text-gray-400 mt-1">Coba ubah filter atau tunggu pengisian kuisioner.</p>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/data/partials/detail-table.blade.php ENDPATH**/ ?>