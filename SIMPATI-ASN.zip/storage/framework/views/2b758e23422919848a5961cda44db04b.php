<?php
    $isLoggedIn = auth()->check();
    $isAdmin    = $isLoggedIn && auth()->user()->isAdmin();
    $userName   = $isLoggedIn ? auth()->user()->name : '';
?>

<header class="bg-white border-b border-gray-200 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">

        
        <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-3">
            <img src="<?php echo e(asset('images/favicon.png')); ?>" alt="Logo SIMPATI ASN" class="w-10 h-10 rounded-xl object-cover">
            <span class="leading-tight">
                <span class="block text-lg font-extrabold tracking-tight text-gray-900">SIMPATI ASN</span>
                <span class="block text-xs text-gray-500">Sistem Monitoring Psikososial ASN</span>
            </span>
        </a>

        
        <nav class="hidden md:flex items-center gap-1">
            <a href="<?php echo e(route('dashboard')); ?>"
               class="flex items-center gap-2 px-4 h-10 rounded-lg text-sm font-semibold transition
                      <?php echo e(request()->routeIs('dashboard') ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'); ?>">
                <i data-lucide="home" class="w-4 h-4"></i> Beranda
            </a>
            <a href="<?php echo e(route('kuisioner')); ?>"
               class="flex items-center gap-2 px-4 h-10 rounded-lg text-sm font-semibold transition
                      <?php echo e(request()->routeIs('kuisioner*') ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'); ?>">
                <i data-lucide="file-text" class="w-4 h-4"></i> Kuisioner
            </a>
            <a href="<?php echo e(route('data')); ?>"
               class="flex items-center gap-2 px-4 h-10 rounded-lg text-sm font-semibold transition
                      <?php echo e(request()->routeIs('data') ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'); ?>">
                <i data-lucide="database" class="w-4 h-4"></i> Data
            </a>
            <a href="<?php echo e(route('tentang')); ?>"
               class="flex items-center gap-2 px-4 h-10 rounded-lg text-sm font-semibold transition
                      <?php echo e(request()->routeIs('tentang') ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'); ?>">
                <i data-lucide="info" class="w-4 h-4"></i> Tentang
            </a>
        </nav>

        
        <?php if($isLoggedIn): ?>
            <div class="flex items-center gap-1">
                
                <?php if($isAdmin): ?>
                <a href="<?php echo e(route('admin.index')); ?>"
                   class="flex items-center gap-2 px-4 h-10 rounded-lg text-sm font-semibold transition
                          <?php echo e(request()->routeIs('admin*') ? 'bg-gray-100 text-gray-900' : 'text-gray-600 hover:bg-gray-100'); ?>">
                    <i data-lucide="layout-dashboard" class="w-4 h-4"></i> Admin Panel
                </a>
                <?php endif; ?>

                
                <div class="flex items-center gap-1.5 px-3 h-10 text-sm text-gray-600">
                    <i data-lucide="user-circle-2" class="w-4 h-4"></i>
                    <span class="font-medium"><?php echo e($userName); ?></span>
                </div>

                
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="flex items-center gap-2 px-4 h-10 rounded-lg text-sm font-semibold text-white bg-brand-600 hover:bg-brand-700 transition shadow-sm">
                        <i data-lucide="log-out" class="w-4 h-4"></i> Logout
                    </button>
                </form>
            </div>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>"
               class="flex items-center gap-2 px-5 h-10 rounded-lg text-sm font-semibold text-white bg-brand-600 hover:bg-brand-700 transition shadow-sm">
                <i data-lucide="log-in" class="w-4 h-4"></i> Login
            </a>
        <?php endif; ?>

    </div>
</header>
<?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/partials/navbar.blade.php ENDPATH**/ ?>