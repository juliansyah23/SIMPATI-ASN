<?php $__env->startSection('title', 'Admin Panel'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .tab-btn { transition: color .15s, border-color .15s; }
    .tab-btn.active { color: #dc2626; border-bottom: 2px solid #dc2626; }
    .tab-btn:not(.active) { color: #6b7280; border-bottom: 2px solid transparent; }
    .tab-btn:not(.active):hover { color: #374151; }
    .tab-content { display: none; }
    .tab-content.active { display: block; }

    /* Status badges */
    .badge-active   { background:#dcfce7; color:#16a34a; }
    .badge-inactive { background:#fee2e2; color:#dc2626; }
    .badge-admin    { background:#ede9fe; color:#7c3aed; }
    .badge-employee { background:#fce7f3; color:#be185d; }
    .badge-aktif    { background:#dcfce7; color:#16a34a; }
    .badge-ditutup  { background:#fef3c7; color:#d97706; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-6 py-8 space-y-6">

    
    <div class="relative bg-gradient-to-r from-brand-700 to-brand-600 rounded-2xl px-8 py-7 text-white shadow-md overflow-hidden">
        <div class="absolute right-8 top-1/2 -translate-y-1/2 opacity-20">
            <i data-lucide="settings" class="w-20 h-20"></i>
        </div>
        <h1 class="text-2xl font-extrabold">Admin Dashboard</h1>
        <p class="mt-1 text-brand-100 text-sm">Selamat datang, Admin User</p>
    </div>

    
    <?php if(session('success')): ?>
        <div class="flex items-center gap-3 bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl px-5 py-3">
            <i data-lucide="check-circle-2" class="w-4 h-4 flex-shrink-0"></i>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="flex items-center gap-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-5 py-3">
            <i data-lucide="alert-circle" class="w-4 h-4 flex-shrink-0"></i>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['icon' => ''.e($s['icon']).'','color' => ''.e($s['color']).'','label' => ''.e($s['label']).'','value' => ''.e($s['value']).'','change' => ''.e($s['change']).'','positive' => $s['positive']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => ''.e($s['icon']).'','color' => ''.e($s['color']).'','label' => ''.e($s['label']).'','value' => ''.e($s['value']).'','change' => ''.e($s['change']).'','positive' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s['positive'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100">

        
        <div class="flex border-b border-gray-100 px-6 gap-1 overflow-x-auto">
            <?php
                $tabs = [
                    'overview'  => ['icon' => 'trending-up',      'label' => 'Overview'],
                    'users'     => ['icon' => 'users-2',           'label' => 'Manajemen User'],
                    'kuisioner' => ['icon' => 'file-text',         'label' => 'Kuisioner'],
                    'settings'  => ['icon' => 'settings',          'label' => 'Pengaturan'],
                ];
            ?>
            <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button
                type="button"
                data-tab="<?php echo e($key); ?>"
                class="tab-btn flex items-center gap-2 py-4 px-4 text-sm font-semibold whitespace-nowrap <?php echo e($tab === $key ? 'active' : ''); ?>">
                <i data-lucide="<?php echo e($t['icon']); ?>" class="w-4 h-4"></i>
                <?php echo e($t['label']); ?>

            </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div id="tab-overview" class="tab-content p-6 <?php echo e($tab === 'overview' ? 'active' : ''); ?>">
            <h2 class="text-base font-bold text-gray-800 mb-5">Activity Analytics</h2>
            <div class="w-full" style="height: 320px;">
                <canvas id="activityChart"></canvas>
            </div>

            
            <div class="grid grid-cols-3 gap-4 mt-6">
                <div class="rounded-xl border border-gray-100 bg-gray-50 p-4 text-center">
                    <p class="text-xs text-gray-500 mb-1">Total Login Bulan Ini</p>
                    <p class="text-xl font-extrabold text-gray-900"><?php echo e($quickSummary['login_bulan_ini']); ?></p>
                </div>
                <div class="rounded-xl border border-gray-100 bg-gray-50 p-4 text-center">
                    <p class="text-xs text-gray-500 mb-1">Pengisian Bulan Ini</p>
                    <p class="text-xl font-extrabold text-gray-900"><?php echo e($quickSummary['pengisian_bulan_ini']); ?></p>
                </div>
                <div class="rounded-xl border border-gray-100 bg-gray-50 p-4 text-center">
                    <p class="text-xs text-gray-500 mb-1">User Aktif</p>
                    <p class="text-xl font-extrabold text-gray-900"><?php echo e($quickSummary['user_aktif']); ?></p>
                </div>
            </div>
        </div>

        
        <div id="tab-users" class="tab-content p-6 <?php echo e($tab === 'users' ? 'active' : ''); ?>">
            <div class="flex items-center justify-between mb-5">
                <h2 class="text-base font-bold text-gray-800">Manajemen User</h2>
                <button type="button"
                    class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold px-4 py-2 rounded-xl shadow-sm transition-colors">
                    <i data-lucide="plus" class="w-4 h-4"></i> Tambah User
                </button>
            </div>

            
            <div class="relative mb-5">
                <span class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <i data-lucide="search" class="w-4 h-4 text-gray-400"></i>
                </span>
                <input
                    type="text"
                    id="userSearch"
                    placeholder="Cari user berdasarkan nama, email, atau NIP..."
                    value="<?php echo e($searchUser); ?>"
                    class="w-full pl-10 pr-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition"
                >
            </div>

            
            <div class="overflow-x-auto">
                <table class="w-full text-sm" id="userTable">
                    <thead>
                        <tr class="border-b border-gray-100">
                            <th class="text-left py-3 px-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">NIP</th>
                            <th class="text-left py-3 px-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">Nama</th>
                            <th class="text-left py-3 px-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">Email</th>
                            <th class="text-left py-3 px-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">Role</th>
                            <th class="text-left py-3 px-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                            <th class="text-left py-3 px-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">Bergabung</th>
                            <th class="text-right py-3 px-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50" id="userTableBody">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50 transition user-row"
                            data-name="<?php echo e(strtolower($u['name'])); ?>"
                            data-email="<?php echo e(strtolower($u['email'])); ?>"
                            data-nip="<?php echo e($u['nip']); ?>">
                            <td class="py-3.5 px-2 text-brand-600 font-mono text-xs"><?php echo e($u['nip']); ?></td>
                            <td class="py-3.5 px-2 font-semibold text-gray-800"><?php echo e($u['name']); ?></td>
                            <td class="py-3.5 px-2 text-gray-500"><?php echo e($u['email']); ?></td>
                            <td class="py-3.5 px-2">
                                <span class="text-xs font-medium px-2.5 py-1 rounded-full
                                    <?php echo e($u['role'] === 'admin' ? 'badge-admin' : 'badge-employee'); ?>">
                                    <?php echo e($u['role']); ?>

                                </span>
                            </td>
                            <td class="py-3.5 px-2">
                                <span class="text-xs font-medium px-2.5 py-1 rounded-full
                                    <?php echo e($u['status'] === 'active' ? 'badge-active' : 'badge-inactive'); ?>">
                                    <?php echo e($u['status']); ?>

                                </span>
                            </td>
                            <td class="py-3.5 px-2 text-gray-500"><?php echo e($u['bergabung']); ?></td>
                            <td class="py-3.5 px-2">
                                <div class="flex items-center justify-end gap-2">
                                    
                                    <a href="<?php echo e(route('admin.user.show', $u['id'])); ?>" title="Lihat Detail"
                                        class="text-brand-600 hover:text-brand-800 transition p-1">
                                        <i data-lucide="eye" class="w-4 h-4"></i>
                                    </a>
                                    
                                    <a href="<?php echo e(route('admin.user.edit', $u['id'])); ?>" title="Edit"
                                        class="text-green-600 hover:text-green-800 transition p-1">
                                        <i data-lucide="pencil" class="w-4 h-4"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <p id="noUserResult" class="hidden text-center text-sm text-gray-400 py-8">Tidak ada user yang cocok.</p>
            </div>
        </div>

        
        <div id="tab-kuisioner" class="tab-content p-6 <?php echo e($tab === 'kuisioner' ? 'active' : ''); ?>">
            <div class="flex items-start justify-between mb-5">
                <div>
                    <h2 class="text-base font-bold text-gray-800">Manajemen Kuisioner</h2>
                    <p class="text-xs text-gray-500 mt-0.5">Buat dan kelola kuisioner seperti Google Forms</p>
                </div>
                <button type="button" disabled title="Pembuatan kuisioner baru sedang dinonaktifkan sementara"
                    class="inline-flex items-center gap-2 bg-gray-200 text-gray-400 text-sm font-semibold px-4 py-2 rounded-xl cursor-not-allowed">
                    <i data-lucide="plus" class="w-4 h-4"></i> Buat Kuisioner Baru
                </button>
            </div>

            
            <?php
                $totalK   = count($questionnaires);
                $aktifK   = collect($questionnaires)->where('status','aktif')->count();
                $totalR   = collect($questionnaires)->sum('respons');
                $ditutupK = collect($questionnaires)->where('status','ditutup')->count();
            ?>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div class="rounded-xl bg-red-50 border border-red-100 px-4 py-4 flex items-center justify-between">
                    <div>
                        <p class="text-xs text-red-500 font-semibold">Total Kuisioner</p>
                        <p class="text-2xl font-extrabold text-gray-900 mt-1"><?php echo e($totalK); ?></p>
                    </div>
                    <i data-lucide="file-text" class="w-8 h-8 text-red-300"></i>
                </div>
                <div class="rounded-xl bg-green-50 border border-green-100 px-4 py-4 flex items-center justify-between">
                    <div>
                        <p class="text-xs text-green-600 font-semibold">Aktif</p>
                        <p class="text-2xl font-extrabold text-gray-900 mt-1"><?php echo e($aktifK); ?></p>
                    </div>
                    <i data-lucide="check-circle-2" class="w-8 h-8 text-green-300"></i>
                </div>
                <div class="rounded-xl bg-purple-50 border border-purple-100 px-4 py-4 flex items-center justify-between">
                    <div>
                        <p class="text-xs text-purple-600 font-semibold">Total Respons</p>
                        <p class="text-2xl font-extrabold text-gray-900 mt-1"><?php echo e($totalR); ?></p>
                    </div>
                    <i data-lucide="bar-chart-2" class="w-8 h-8 text-purple-300"></i>
                </div>
                <div class="rounded-xl bg-amber-50 border border-amber-100 px-4 py-4 flex items-center justify-between">
                    <div>
                        <p class="text-xs text-amber-600 font-semibold">Ditutup</p>
                        <p class="text-2xl font-extrabold text-gray-900 mt-1"><?php echo e($ditutupK); ?></p>
                    </div>
                    <i data-lucide="clock" class="w-8 h-8 text-amber-300"></i>
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border-l-4 <?php echo e($q['status'] === 'aktif' ? 'border-green-500' : 'border-gray-300'); ?>

                            border border-gray-100 rounded-xl p-5 flex flex-col gap-4 bg-white">

                    
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex-1">
                            <p class="text-sm font-bold text-gray-900 leading-snug"><?php echo e($q['judul']); ?></p>
                            <div class="flex flex-wrap items-center gap-2 mt-1.5">
                                <span class="text-xs font-medium px-2 py-0.5 rounded-full
                                    <?php echo e($q['status'] === 'aktif' ? 'badge-aktif' : 'badge-ditutup'); ?>

                                    flex items-center gap-1">
                                    <?php if($q['status'] === 'aktif'): ?>
                                        <i data-lucide="check-circle-2" class="w-3 h-3"></i> Aktif
                                    <?php else: ?>
                                        <i data-lucide="clock" class="w-3 h-3"></i> Ditutup
                                    <?php endif; ?>
                                </span>
                                <span class="text-xs text-gray-400">Tahun <?php echo e($q['tahun']); ?></span>
                            </div>
                        </div>
                        <i data-lucide="file-text" class="w-5 h-5 text-gray-300 flex-shrink-0"></i>
                    </div>

                    
                    <div class="grid grid-cols-2 gap-3 text-xs">
                        <div>
                            <p class="text-gray-400">Respons</p>
                            <p class="font-bold text-gray-800 text-base mt-0.5"><?php echo e($q['respons']); ?></p>
                        </div>
                        <div>
                            <p class="text-gray-400">Dibuat</p>
                            <p class="font-semibold text-gray-700 mt-0.5"><?php echo e($q['dibuat']); ?></p>
                        </div>
                    </div>

                    
                    <div class="flex gap-2">
                        <a href="<?php echo e(route('admin.kuisioner.edit', $q['id'])); ?>"
                            class="flex-1 inline-flex items-center justify-center gap-1.5 border border-brand-200 text-brand-600 hover:bg-brand-50 text-xs font-semibold py-2 rounded-lg transition-colors">
                            <i data-lucide="pencil" class="w-3.5 h-3.5"></i> Edit
                        </a>
                        <a href="<?php echo e(route('admin.kuisioner.respons', $q['id'])); ?>"
                            class="flex-1 inline-flex items-center justify-center gap-1.5 border border-purple-200 text-purple-600 hover:bg-purple-50 text-xs font-semibold py-2 rounded-lg transition-colors">
                            <i data-lucide="bar-chart-2" class="w-3.5 h-3.5"></i> Respons
                        </a>
                    </div>

                    
                    <div class="flex items-center justify-between pt-1 border-t border-gray-50">
                        <div class="flex items-center gap-2">
                            
                            <button type="button" title="Duplikat"
                                class="text-gray-400 hover:text-gray-600 transition p-1">
                                <i data-lucide="copy" class="w-4 h-4"></i>
                            </button>
                            
                            <button type="button" title="Unduh"
                                class="text-gray-400 hover:text-gray-600 transition p-1">
                                <i data-lucide="download" class="w-4 h-4"></i>
                            </button>
                            
                            <form method="POST" action="<?php echo e(route('admin.kuisioner.delete', $q['id'])); ?>"
                                onsubmit="return confirm('Hapus kuisioner ini?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" title="Hapus"
                                    class="text-red-400 hover:text-red-600 transition p-1">
                                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                                </button>
                            </form>
                        </div>

                        
                        <form method="POST" action="<?php echo e(route('admin.kuisioner.toggle', $q['id'])); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="<?php echo e($q['status'] === 'aktif' ? 'tutup' : 'buka'); ?>">
                            <button type="submit"
                                class="text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors
                                    <?php echo e($q['status'] === 'aktif'
                                        ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                                        : 'bg-green-100 text-green-700 hover:bg-green-200'); ?>">
                                <?php echo e($q['status'] === 'aktif' ? 'Tutup' : 'Buka'); ?>

                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div id="tab-settings" class="tab-content p-6 <?php echo e($tab === 'settings' ? 'active' : ''); ?>">
            <h2 class="text-base font-bold text-gray-800 mb-6">Pengaturan Sistem</h2>

            <div class="space-y-5 max-w-xl">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Nama Sistem</label>
                    <input type="text" value="SIMPATI ASN"
                        class="w-full px-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500 transition">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Institusi</label>
                    <input type="text" value="BRIN"
                        class="w-full px-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500 transition">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Domain Email yang Diizinkan</label>
                    <input type="text" value="brin.go.id"
                        class="w-full px-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500 transition">
                </div>
                
                <div class="flex items-center justify-between py-3 border-t border-gray-100">
                    <div>
                        <p class="text-sm font-medium text-gray-700">Izinkan Registrasi Publik</p>
                        <p class="text-xs text-gray-400 mt-0.5">Pegawai dapat mendaftar sendiri tanpa perlu diundang admin</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" class="sr-only peer" checked>
                        <div class="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:bg-brand-600
                                    peer-focus:outline-none transition-colors duration-200 after:content-['']
                                    after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full
                                    after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-5"></div>
                    </label>
                </div>
                
                <button type="button"
                    class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold px-6 py-2.5 rounded-xl shadow-sm transition-colors">
                    <i data-lucide="save" class="w-4 h-4"></i> Simpan Pengaturan
                </button>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// ── Tab switching ──────────────────────────────────────────────────────────
(function () {
    const btns     = document.querySelectorAll('.tab-btn');
    const contents = document.querySelectorAll('.tab-content');

    btns.forEach(btn => {
        btn.addEventListener('click', () => {
            btns.forEach(b => b.classList.remove('active'));
            contents.forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById('tab-' + btn.dataset.tab).classList.add('active');

            // Re-render lucide icons inside newly-shown tabs
            if (window.lucide) lucide.createIcons();
        });
    });
})();

// ── Activity Chart ─────────────────────────────────────────────────────────
(function () {
    const ctx = document.getElementById('activityChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($activityChart['labels']); ?>,
            datasets: [
                {
                    label: 'Total Logins',
                    data: <?php echo json_encode($activityChart['logins']); ?>,
                    backgroundColor: '#3b82f6',
                    borderRadius: 6,
                    barPercentage: 0.5,
                },
                {
                    label: 'Submissions',
                    data: <?php echo json_encode($activityChart['submissions']); ?>,
                    backgroundColor: '#10b981',
                    borderRadius: 6,
                    barPercentage: 0.5,
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, pointStyle: 'rect' } } },
            scales: {
                x: { grid: { display: false } },
                y: { beginAtZero: true, grid: { color: '#f3f4f6' } },
            },
        },
    });
})();

// ── Live user search ───────────────────────────────────────────────────────
(function () {
    const input   = document.getElementById('userSearch');
    const rows    = document.querySelectorAll('.user-row');
    const noResult= document.getElementById('noUserResult');
    if (!input) return;

    input.addEventListener('input', () => {
        const q = input.value.toLowerCase().trim();
        let visible = 0;
        rows.forEach(row => {
            const match = !q
                || row.dataset.name.includes(q)
                || row.dataset.email.includes(q)
                || row.dataset.nip.includes(q);
            row.style.display = match ? '' : 'none';
            if (match) visible++;
        });
        noResult.classList.toggle('hidden', visible > 0);
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/admin/index.blade.php ENDPATH**/ ?>