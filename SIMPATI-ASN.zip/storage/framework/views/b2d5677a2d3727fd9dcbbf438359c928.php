<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="bg-gradient-to-b from-brand-700 via-brand-600 to-brand-600 text-white">
        <div class="max-w-5xl mx-auto px-6 pt-16 pb-12 text-center">
            <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight">SIMPATI ASN</h1>
            <p class="mt-4 text-lg md:text-xl font-medium text-white/90">
                Sistem Monitoring Psikososial ASN di Era WFO/WFA
            </p>
            <p class="mt-3 max-w-3xl mx-auto text-sm md:text-base text-white/75">
                Dashboard analisis dan monitoring kondisi psikososial Aparatur Sipil Negara dalam
                lingkungan kerja Work From Office (WFO) dan Work From Anywhere (WFA)
            </p>
        </div>
    </section>

    
    <section class="max-w-7xl mx-auto px-6 -mt-10 relative z-10">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['icon' => $stat['icon'],'color' => $stat['color'],'label' => $stat['label'],'value' => $stat['value'],'change' => $stat['change'],'positive' => $stat['positive']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['icon']),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['color']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['label']),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['value']),'change' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['change']),'positive' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['positive'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    
    <section class="max-w-7xl mx-auto px-6 mt-10">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">

            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h2 class="text-xl font-bold text-gray-900">Persepsi terhadap Kebijakan WFO/WFA</h2>
                    <p class="text-sm text-gray-500 mt-1">Distribusi respon berdasarkan skala Likert (1-5)</p>
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Pilih Kategori:</label>
                    <select id="kategori-select"
                            class="w-full h-12 rounded-lg border border-gray-300 px-4 text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if($selectedCategory === $key): echo 'selected'; endif; ?>>
                                <?php echo e($cat['label']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Jenis Diagram:</label>
                    <select id="chartType"
                            class="w-full h-12 rounded-lg border border-gray-300 px-4 text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500">
                        <option value="pie">Diagram Lingkaran</option>
                        <option value="bar">Diagram Batang</option>
                        <option value="polarArea">Diagram Pohon</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-10 mt-10">

                
                <div>
                    <h3 class="text-base font-bold text-gray-900 mb-4">Distribusi Respon</h3>
                    <div class="relative h-80">
                        <canvas id="distributionChart"></canvas>
                    </div>
                </div>

                
                <div id="category-panel">
                    <?php echo $__env->make('dashboard.partials.category-panel', [
                        'activeCategory' => $activeCategory,
                        'colors'         => $colors,
                        'table'          => $table,
                        'total'          => $total,
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
    </section>

    
    <section class="max-w-7xl mx-auto px-6 mt-10 mb-16">
        <h2 class="text-xl font-bold text-gray-900 mb-5">Insight Psikososial ASN</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $insights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $bg = match ($insight['color']) {
                        'red'    => 'bg-red-50 border-red-100',
                        'green'  => 'bg-emerald-50 border-emerald-100',
                        'purple' => 'bg-purple-50 border-purple-100',
                        default  => 'bg-gray-50 border-gray-100',
                    };
                    $title = match ($insight['color']) {
                        'red'    => 'text-red-700',
                        'green'  => 'text-emerald-700',
                        'purple' => 'text-purple-700',
                        default  => 'text-gray-700',
                    };
                    $body = match ($insight['color']) {
                        'red'    => 'text-red-600',
                        'green'  => 'text-emerald-600',
                        'purple' => 'text-purple-600',
                        default  => 'text-gray-600',
                    };
                ?>
                <div class="rounded-2xl border <?php echo e($bg); ?> p-6">
                    <p class="font-bold <?php echo e($title); ?>"><?php echo e($insight['title']); ?></p>
                    <p class="text-sm <?php echo e($body); ?> mt-2 leading-relaxed"><?php echo e($insight['text']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Data chart bersifat "current" (bisa diganti saat AJAX refresh),
        // makanya pakai `let` bukan `const`.
        let distribution  = <?php echo json_encode($activeCategory['distribution'], 15, 512) ?>;
        let likertLabels  = <?php echo json_encode($activeCategory['labels_likert'], 15, 512) ?>;
        const colors      = <?php echo json_encode($colors, 15, 512) ?>;

        let labels           = Object.keys(distribution).map(k => `${likertLabels[k]} (${k})`);
        let data             = Object.values(distribution);
        let backgroundColors = Object.keys(distribution).map(k => colors[k]);

        let chart;
        let currentChartType = 'pie';
        const ctx = document.getElementById('distributionChart');

        function renderChart(type) {
            currentChartType = type;
            if (chart) chart.destroy();

            const isCartesian = type === 'bar';
            const isPolar     = type === 'polarArea';

            chart = new Chart(ctx, {
                type: type,
                plugins: [ChartDataLabels], // ← daftarkan plugin khusus chart ini
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: backgroundColors,
                        borderWidth: isCartesian ? 0 : 2,
                        borderColor: '#ffffff',
                    }],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: isPolar },
                        tooltip: {
                            callbacks: {
                                label: (ctx) => {
                                    const total = data.reduce((a, b) => a + b, 0);
                                    const raw   = ctx.raw ?? 0;
                                    const pct   = total > 0 ? (raw / total * 100).toFixed(1) : '0.0';
                                    return `${ctx.label}: ${raw} responden (${pct}%)`;
                                },
                            },
                        },
                        datalabels: {
                            color: '#ffffff',
                            font: { weight: 'bold', size: 12 },
                            formatter: (value) => {
                                const total = data.reduce((a, b) => a + b, 0);
                                if (total === 0 || value === 0) return '';
                                const pct = (value / total * 100).toFixed(1);
                                return `${pct}%`; // bisa diganti jadi `${value}` kalau mau tampilkan angka respondennya
                            },
                            display: (ctx) => {
                                // sembunyikan label kalau slice-nya terlalu kecil (biar nggak numpuk)
                                const value = ctx.dataset.data[ctx.dataIndex];
                                const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                                return total > 0 && (value / total) > 0.03; // sembunyikan jika < 3%
                            },
                        },
                    },
                    scales: isCartesian
                        ? { y: { beginAtZero: true, grid: { color: '#f3f4f6' } } }
                        : {},
                },
            });
        }

        renderChart('pie');

        document.getElementById('chartType').addEventListener('change', (e) => {
            renderChart(e.target.value);
        });

        // ─────────────────────────────────────────────────────────────
        //  AJAX: ambil ulang data setiap dropdown kategori berganti
        // ─────────────────────────────────────────────────────────────
        const kategoriSelect = document.getElementById('kategori-select');
        const dashboardDataUrl = '<?php echo e(route('dashboard.data')); ?>';

        kategoriSelect.addEventListener('change', async (e) => {
            try {
                const res = await fetch(`${dashboardDataUrl}?kategori=${encodeURIComponent(e.target.value)}`, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                if (!res.ok) throw new Error('Request gagal');
                const json = await res.json();

                // Ganti HTML legend + distribusi + tabel + ringkasan
                document.getElementById('category-panel').innerHTML = json.panelHtml;
                if (window.lucide) lucide.createIcons();

                // Hitung ulang data chart lalu render ulang dengan tipe yang sedang dipilih
                distribution     = json.distribution;
                likertLabels     = json.labelsLikert;
                labels           = Object.keys(distribution).map(k => `${likertLabels[k]} (${k})`);
                data             = Object.values(distribution);
                backgroundColors = Object.keys(distribution).map(k => json.colors[k]);

                renderChart(currentChartType);
            } catch (err) {
                console.error('Gagal memuat data dashboard:', err);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/dashboard/index.blade.php ENDPATH**/ ?>