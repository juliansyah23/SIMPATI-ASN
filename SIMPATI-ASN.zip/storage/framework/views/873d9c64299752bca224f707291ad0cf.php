<?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="px-3 py-4 font-semibold text-gray-800"><?php echo e($center['name']); ?></td>
        <td class="px-3 py-4 text-center text-blue-600 font-semibold"><?php echo e($center['respons']); ?></td>
        <td class="px-3 py-4 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-bold <?php echo e($center['produktivitas'] >= 4.5 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'); ?>">
                <?php echo e(number_format($center['produktivitas'], 1)); ?>

            </span>
        </td>
        <td class="px-3 py-4 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-bold <?php echo e($center['kolaborasi'] >= 4.5 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'); ?>">
                <?php echo e(number_format($center['kolaborasi'], 1)); ?>

            </span>
        </td>
        <td class="px-3 py-4 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-bold <?php echo e($center['wlb'] >= 4.5 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'); ?>">
                <?php echo e(number_format($center['wlb'], 1)); ?>

            </span>
        </td>
        <td class="px-3 py-4 text-center">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-bold <?php echo e($center['stres'] <= 2.0 ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'); ?>">
                <?php echo e(number_format($center['stres'], 1)); ?>

            </span>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/data/partials/centers-table.blade.php ENDPATH**/ ?>