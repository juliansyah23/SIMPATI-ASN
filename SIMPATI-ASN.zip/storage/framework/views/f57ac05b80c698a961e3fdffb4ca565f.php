<?php $__env->startSection('title', 'Isi Kuisioner'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    /* ── Likert 1-5 boxes ─────────────────────────────────────────────── */
    .likert-radio { display: none; }
    .likert-radio:checked + .likert-label {
        background-color: #fff;
        color: #111827;
        border-color: #dc2626;
        box-shadow: 0 0 0 3px rgba(220,38,38,.15);
    }
    .likert-label {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 3.25rem;
        border: 2px solid #e5e7eb;
        border-radius: .75rem;
        font-size: .95rem;
        font-weight: 600;
        color: #374151;
        cursor: pointer;
        background: #fff;
        transition: background .15s, color .15s, border-color .15s, box-shadow .15s;
        user-select: none;
    }
    .likert-label:hover { border-color: #dc2626; color: #dc2626; }

    /* ── Demografi pilihan kartu ──────────────────────────────────────── */
    .choice-radio { display: none; }
    .choice-radio:checked + .choice-label {
        border-color: #dc2626;
        background-color: #fef2f2;
        color: #111827;
    }
    .choice-radio:checked + .choice-label .choice-dot {
        border-color: #dc2626;
        background-color: #dc2626;
        box-shadow: inset 0 0 0 3px #fff;
    }
    .choice-label {
        display: flex;
        align-items: center;
        gap: .75rem;
        width: 100%;
        padding: .9rem 1.25rem;
        border: 1.5px solid #e5e7eb;
        border-radius: .75rem;
        font-size: .9rem;
        font-weight: 600;
        color: #374151;
        cursor: pointer;
        transition: border-color .15s, background-color .15s, color .15s;
        user-select: none;
    }
    .choice-label:hover { border-color: #dc2626; }
    .choice-dot {
        flex-shrink: 0;
        width: 1.1rem;
        height: 1.1rem;
        border-radius: 9999px;
        border: 2px solid #9ca3af;
        background: #fff;
        transition: border-color .15s, background-color .15s, box-shadow .15s;
    }

    #progress-fill { transition: width .3s ease; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto px-6 py-10 space-y-6">

    
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
        <div class="flex items-start gap-4">
            <span class="flex items-center justify-center w-12 h-12 rounded-xl bg-red-50 text-brand-600 shrink-0">
                <i data-lucide="file-text" class="w-6 h-6"></i>
            </span>
            <div>
                <h1 class="text-xl font-extrabold text-gray-900"><?php echo e($kuesioner['judul']); ?></h1>
                <p class="mt-1 text-sm text-gray-500"><?php echo e($kuesioner['deskripsi'] ?? ''); ?></p>
            </div>
        </div>

        
        <div class="mt-6">
            <div class="flex justify-between text-sm text-gray-500 mb-1.5">
                <span>Kategori <?php echo e($step); ?> dari <?php echo e($totalSteps); ?></span>
                <span><?php echo e($progress); ?>% Selesai</span>
            </div>
            <div class="w-full bg-gray-100 rounded-full h-2">
                <div id="progress-fill" class="bg-brand-600 h-2 rounded-full" style="width: <?php echo e($progress); ?>%"></div>
            </div>
        </div>
    </div>

    
    <?php if($errors->any()): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-5 py-4">
            <p class="font-semibold mb-1">Harap lengkapi semua jawaban:</p>
            <ul class="list-disc list-inside space-y-0.5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <form method="POST"
          action="<?php echo e($step === $totalSteps ? route('kuisioner.submit', $kuesioner['id']) : route('kuisioner.step', $kuesioner['id'])); ?>"
          id="kuisioner-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="step" value="<?php echo e($step); ?>">
        <input type="hidden" name="action" id="form-action" value="next">

        
        <?php if($current['type'] === 'demografi'): ?>
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
                <h2 class="text-lg font-bold text-gray-900"><?php echo e($current['title']); ?></h2>
                <p class="mt-1 text-sm text-gray-500"><?php echo e($current['subtitle']); ?></p>
            </div>

            <?php $__currentLoopData = $current['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
                    <p class="text-sm font-bold text-gray-800 mb-4">
                        <?php echo e($field['label']); ?> <span class="text-red-500">*</span>
                    </p>

                    <?php if($field['field_key'] === 'kategori_jabatan'): ?>
                        
                        <?php $selected = $draft['demografi'][$field['id']] ?? old("demografi.{$field['id']}"); ?>
                        <div class="relative">
                            <select name="demografi[<?php echo e($field['id']); ?>]"
                                    class="w-full h-11 pl-4 pr-10 rounded-xl border border-gray-300 text-sm text-gray-800
                                           focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent
                                           transition bg-white appearance-none cursor-pointer">
                                <option value="" disabled <?php echo e($selected ? '' : 'selected'); ?>>— Pilih Kategori Jabatan —</option>
                                <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($opt); ?>" <?php echo e($selected === $opt ? 'selected' : ''); ?>><?php echo e($opt); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="pointer-events-none absolute inset-y-0 right-3 flex items-center text-gray-400">
                                <i data-lucide="chevron-down" class="w-4 h-4"></i>
                            </span>
                        </div>
                    <?php else: ?>
                        
                        <div class="space-y-2.5">
                            <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $checked = ($draft['demografi'][$field['id']] ?? old("demografi.{$field['id']}")) === $opt;
                                ?>
                                <label class="block cursor-pointer">
                                    <input type="radio"
                                           class="choice-radio"
                                           name="demografi[<?php echo e($field['id']); ?>]"
                                           value="<?php echo e($opt); ?>"
                                           <?php echo e($checked ? 'checked' : ''); ?>>
                                    <span class="choice-label">
                                        <span class="choice-dot"></span>
                                        <?php echo e($opt); ?>

                                    </span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <?php $__errorArgs = ["demografi.{$field['id']}"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php else: ?>
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
                <h2 class="text-lg font-bold text-gray-900"><?php echo e($current['title']); ?></h2>
                <p class="mt-1 text-sm text-gray-500"><?php echo e($current['subtitle']); ?></p>
            </div>

            <?php $__currentLoopData = $current['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $jawabanLama = $draft['jawaban'][$q['id']] ?? old("jawaban.{$q['id']}"); ?>
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
                    <p class="text-sm font-semibold text-gray-800 mb-4">
                        <?php echo e($q['pertanyaan']); ?> <span class="text-red-500">*</span>
                    </p>

                    <?php
                        $likertLabels = [
                            1 => 'Sangat Tidak Setuju',
                            2 => 'Tidak Setuju',
                            3 => 'Cukup Setuju',
                            4 => 'Setuju',
                            5 => 'Sangat Setuju',
                        ];
                    ?>
                    <div class="grid grid-cols-5 gap-2 sm:gap-3">
                        <?php for($val = 1; $val <= 5; $val++): ?>
                            <div class="flex flex-col items-center">
                                <input type="radio"
                                       id="q<?php echo e($q['id']); ?>_v<?php echo e($val); ?>"
                                       name="jawaban[<?php echo e($q['id']); ?>]"
                                       value="<?php echo e($val); ?>"
                                       class="likert-radio"
                                       <?php echo e((string) $jawabanLama === (string) $val ? 'checked' : ''); ?>>
                                <label for="q<?php echo e($q['id']); ?>_v<?php echo e($val); ?>" class="likert-label w-full"><?php echo e($val); ?></label>
                                <span class="mt-1.5 text-[11px] leading-tight text-center text-gray-400">
                                    <?php echo e($likertLabels[$val]); ?>

                                </span>
                            </div>
                        <?php endfor; ?>
                    </div>

                    <?php $__errorArgs = ["jawaban.{$q['id']}"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $current['esai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
                    <label for="esai_<?php echo e($e['id']); ?>" class="block text-sm font-semibold text-gray-800 mb-3">
                        <?php echo e($e['pertanyaan']); ?> <span class="text-red-500">*</span>
                    </label>
                    <textarea
                        id="esai_<?php echo e($e['id']); ?>"
                        name="esai[<?php echo e($e['id']); ?>]"
                        rows="4"
                        placeholder="Masukkan jawaban Anda"
                        class="w-full text-sm border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition resize-none"
                    ><?php echo e($draft['esai'][$e['id']] ?? old("esai.{$e['id']}")); ?></textarea>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-6 py-4 flex items-center justify-between">
            <?php if($step > 1): ?>
                <button type="submit" onclick="document.getElementById('form-action').value='prev'"
                    class="inline-flex items-center gap-1.5 text-sm font-semibold text-gray-500 hover:text-gray-700 px-4 py-2 rounded-lg transition">
                    <i data-lucide="chevron-left" class="w-4 h-4"></i> Sebelumnya
                </button>
            <?php else: ?>
                <span class="inline-flex items-center gap-1.5 text-sm font-semibold text-gray-300 px-4 py-2">
                    <i data-lucide="chevron-left" class="w-4 h-4"></i> Sebelumnya
                </span>
            <?php endif; ?>

            <span class="text-sm font-semibold text-amber-500"><?php echo e($step); ?> / <?php echo e($totalSteps); ?></span>

            <?php if($step < $totalSteps): ?>
                <button type="submit" onclick="document.getElementById('form-action').value='next'"
                    class="inline-flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 active:bg-brand-800 text-white text-sm font-semibold px-6 py-2.5 rounded-xl shadow-sm transition-colors">
                    Selanjutnya <i data-lucide="chevron-right" class="w-4 h-4"></i>
                </button>
            <?php else: ?>
                <button type="submit"
                    class="inline-flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 active:bg-brand-800 text-white text-sm font-semibold px-6 py-2.5 rounded-xl shadow-sm transition-colors">
                    <i data-lucide="send" class="w-4 h-4"></i> Kirim Kuisioner
                </button>
            <?php endif; ?>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/kuisioner/show.blade.php ENDPATH**/ ?>