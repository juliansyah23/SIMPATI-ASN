<h3 class="text-base font-bold text-gray-900 mb-4">Rata-rata Skor Kategori</h3>
<div class="rounded-xl border border-gray-100 px-6 py-6">
    <div class="flex items-end gap-2">
        <span class="text-4xl font-extrabold text-gray-900"><?php echo e(number_format($activeCategory['rata_rata'], 2, ',', '.')); ?></span>
        <span class="text-base font-medium text-gray-500 mb-1">/ 5,00</span>
    </div>
    <span
        class="inline-block mt-3 px-3 py-1 rounded-full text-xs font-bold text-white"
        style="background-color: <?php echo e($activeCategory['kelas'] ? ($colors[$activeCategory['kelas']] ?? '#6b7280') : '#9ca3af'); ?>"
    >
        <?php echo e($activeCategory['kelas_label']); ?>

    </span>
    <div class="mt-4 h-2 w-full rounded-full bg-gray-100 overflow-hidden">
        <div
            class="h-full rounded-full"
            style="width: <?php echo e(min(100, ($activeCategory['rata_rata'] / 5) * 100)); ?>%; background-color: <?php echo e($activeCategory['kelas'] ? ($colors[$activeCategory['kelas']] ?? '#6b7280') : '#9ca3af'); ?>"
        ></div>
    </div>
    <p class="text-xs text-gray-500 mt-3">
        Dihitung dari rata-rata skor Likert (skala 1–5) seluruh pertanyaan pada kategori ini,
        dari <?php echo e($total); ?> responden, lalu diklasifikasikan pakai kriteria kelas (panjang kelas 0,8).
    </p>
</div>

<h3 class="text-base font-bold text-gray-900 mt-10 mb-4">Tabel Distribusi Frekuensi</h3>
<div class="overflow-x-auto rounded-xl border border-gray-100">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 text-gray-600">
            <tr>
                <th class="text-left font-semibold px-5 py-3">Kriteria kelas</th>
                <th class="text-center font-semibold px-5 py-3">Frekuensi</th>
                <th class="text-center font-semibold px-5 py-3">Persentase</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-5 py-3 text-gray-700"><?php echo e($row['label']); ?> (<?php echo e($row['scale']); ?>)</td>
                    <td class="px-5 py-3 text-center font-semibold text-gray-900"><?php echo e($row['count']); ?></td>
                    <td class="px-5 py-3 text-center text-gray-600"><?php echo e($row['percent']); ?>%</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr class="bg-gray-50 font-bold text-gray-900">
                <td class="px-5 py-3">Total</td>
                <td class="px-5 py-3 text-center"><?php echo e($total); ?></td>
                <td class="px-5 py-3 text-center">100.0%</td>
            </tr>
        </tfoot>
    </table>
</div>
<h3 class="text-base font-bold text-gray-900 mt-10 mb-4">Distribusi Respon</h3>
<div class="space-y-3">
    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex items-center justify-between bg-gray-50 rounded-xl px-5 py-4">
            <span class="flex items-center gap-3 text-sm font-semibold text-gray-700">
                <span class="w-3 h-3 rounded-sm shrink-0" style="background-color: <?php echo e($colors[$row['scale']] ?? '#ccc'); ?>"></span>
                <?php echo e($activeCategory['labels_kualitas'][$row['scale']]); ?> (<?php echo e($row['scale']); ?>)
            </span>
            <span class="text-right">
                <span class="block text-sm font-bold text-gray-900"><?php echo e($row['count']); ?> responden</span>
                <span class="block text-xs text-gray-500"><?php echo e($row['percent']); ?>%</span>
            </span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="bg-red-50 rounded-xl px-5 py-4 mt-6">
    <p class="text-sm font-bold text-red-700">Ringkasan</p>
    <p class="text-sm text-red-600 mt-1">Total Responden: <?php echo e($total); ?> pegawai</p>
    <p class="text-sm text-red-600 mt-1">
        Rata-rata Skor: <?php echo e(number_format($activeCategory['rata_rata'], 2, ',', '.')); ?> / 5,00
        — <?php echo e($activeCategory['kelas_label']); ?>

    </p>
</div>
<?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/dashboard/partials/category-panel.blade.php ENDPATH**/ ?>