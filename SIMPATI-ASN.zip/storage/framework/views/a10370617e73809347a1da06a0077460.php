<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'icon' => 'activity',
    'color' => 'red',
    'label' => '',
    'value' => '',
    'unit' => '',
    'subtitle' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'icon' => 'activity',
    'color' => 'red',
    'label' => '',
    'value' => '',
    'unit' => '',
    'subtitle' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $colorMap = [
        'red'    => 'text-red-500',
        'green'  => 'text-emerald-500',
        'purple' => 'text-purple-500',
        'orange' => 'text-orange-500',
    ];
    $iconColor = $colorMap[$color] ?? 'text-gray-500';
?>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
    <div class="flex items-center justify-between">
        <p class="text-sm text-gray-500"><?php echo e($label); ?></p>
        <i data-lucide="<?php echo e($icon); ?>" class="w-5 h-5 <?php echo e($iconColor); ?>"></i>
    </div>
    <p class="mt-3">
        <span class="text-3xl font-extrabold text-gray-900"><?php echo e($value); ?></span>
        <?php if($unit): ?>
            <span class="text-base font-semibold text-gray-400"><?php echo e($unit); ?></span>
        <?php endif; ?>
    </p>
    <p class="text-xs text-gray-400 mt-1"><?php echo e($subtitle); ?></p>
</div>
<?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/components/data-stat-card.blade.php ENDPATH**/ ?>