<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'icon' => 'activity',
    'color' => 'red',
    'label' => '',
    'value' => '',
    'change' => '',
    'positive' => true,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'icon' => 'activity',
    'color' => 'red',
    'label' => '',
    'value' => '',
    'change' => '',
    'positive' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $colorMap = [
        'red'    => 'bg-red-600',
        'green'  => 'bg-emerald-500',
        'purple' => 'bg-purple-500',
        'orange' => 'bg-orange-500',
    ];
    $iconBg = $colorMap[$color] ?? 'bg-gray-500';
    $changeColor = $positive ? 'text-emerald-600' : 'text-red-500';
?>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col gap-4">
    <div class="flex items-center justify-between">
        <span class="flex items-center justify-center w-11 h-11 rounded-xl <?php echo e($iconBg); ?> text-white">
            <i data-lucide="<?php echo e($icon); ?>" class="w-5 h-5"></i>
        </span>
        <span class="text-sm font-semibold <?php echo e($changeColor); ?>"><?php echo e($change); ?></span>
    </div>
    <div>
        <p class="text-sm text-gray-500"><?php echo e($label); ?></p>
        <p class="text-2xl font-extrabold text-gray-900 mt-1"><?php echo e($value); ?></p>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/components/stat-card.blade.php ENDPATH**/ ?>