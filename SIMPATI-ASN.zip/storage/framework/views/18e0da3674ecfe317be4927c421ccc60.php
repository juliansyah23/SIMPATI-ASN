<?php $__env->startSection('title', 'Kuisioner'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-6 py-10 space-y-8">

    
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
        <h1 class="text-2xl font-bold text-gray-900">Kuisioner Psikososial</h1>
        <p class="mt-1 text-sm text-gray-500">Isi kuisioner evaluasi kondisi psikososial ASN dalam mode WFA dan WFO</p>
    </div>

    
    <?php if(session('success')): ?>
        <div class="flex items-center gap-3 bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl px-5 py-3.5">
            <i data-lucide="check-circle-2" class="w-5 h-5 flex-shrink-0"></i>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="flex items-center gap-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-5 py-3.5">
            <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0"></i>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
        <h2 class="text-base font-bold text-gray-800 mb-5">Kuisioner Tersedia</h2>

        <div class="space-y-4">
            <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center justify-between gap-4 border border-gray-100 rounded-xl px-6 py-5 hover:bg-gray-50 transition">
                
                <div class="flex-1 min-w-0">
                    <div class="flex flex-wrap items-center gap-2 mb-1">
                        <span class="text-sm font-semibold text-gray-900"><?php echo e($q['judul']); ?></span>

                        
                        <?php if($q['status'] === 'aktif' && !$q['sudah_diisi']): ?>
                            <span class="inline-flex items-center gap-1 text-xs font-medium bg-amber-50 text-amber-600 border border-amber-200 rounded-full px-2.5 py-0.5">
                                <i data-lucide="clock" class="w-3 h-3"></i> Belum Diisi
                            </span>
                        <?php elseif($q['status'] === 'aktif' && $q['sudah_diisi']): ?>
                            <span class="inline-flex items-center gap-1 text-xs font-medium bg-green-50 text-green-700 border border-green-200 rounded-full px-2.5 py-0.5">
                                <i data-lucide="check-circle-2" class="w-3 h-3"></i> Sudah Diisi
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center text-xs font-medium bg-gray-100 text-gray-500 rounded-full px-2.5 py-0.5">
                                Ditutup
                            </span>
                        <?php endif; ?>
                    </div>
                    <p class="text-xs text-gray-400">Tahun: <?php echo e($q['tahun']); ?> &nbsp;·&nbsp; Dibuat oleh: <?php echo e($q['dibuat_oleh']); ?></p>
                </div>

                
                <div class="flex-shrink-0">
                    <?php if($q['status'] === 'aktif' && !$q['sudah_diisi']): ?>
                        <a href="<?php echo e(route('kuisioner.show', $q['id'])); ?>"
                           class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-sm transition-colors">
                            <i data-lucide="file-edit" class="w-4 h-4"></i>
                            Isi Kuisioner
                        </a>
                    <?php elseif($q['status'] === 'aktif' && $q['sudah_diisi']): ?>
                        <span class="text-sm text-gray-400 italic">Terima kasih sudah mengisi</span>
                    <?php else: ?>
                        <span class="text-sm text-gray-400 italic">Terima kasih sudah mengisi</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 px-8 py-6">
        <h2 class="text-base font-bold text-gray-800 mb-5">Riwayat Pengisian Saya</h2>

        <?php if(count($history) > 0): ?>
            <div class="space-y-4">
                <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between gap-4 border border-gray-100 rounded-xl px-6 py-5 hover:bg-gray-50 transition">
                    <div class="flex-1 min-w-0">
                        <div class="flex flex-wrap items-center gap-2 mb-1">
                            <span class="text-sm font-semibold text-gray-900"><?php echo e($h['judul']); ?></span>

                            
                            <span class="text-xs font-medium bg-purple-100 text-purple-700 rounded-full px-2.5 py-0.5">
                                <?php echo e($h['mode_kerja']); ?>

                            </span>

                            
                            <span class="text-xs font-medium bg-green-100 text-green-700 rounded-full px-2.5 py-0.5">
                                Avg: <?php echo e($h['rata_rata']); ?>/5
                            </span>
                        </div>
                        <p class="text-xs text-gray-400 mb-1">Dikirim: <?php echo e($h['dikirim']); ?></p>
                        <?php if(!empty($h['komentar'])): ?>
                            <p class="text-xs text-gray-500 italic">"<?php echo e($h['komentar']); ?>"</p>
                        <?php endif; ?>
                    </div>

                    <div class="flex-shrink-0">
                        <a href="<?php echo e(route('kuisioner.riwayat.detail', $h['id'])); ?>"
                            class="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-sm transition-colors">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                            Lihat Detail
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="flex flex-col items-center justify-center py-12 text-gray-400">
                <i data-lucide="inbox" class="w-12 h-12 mb-3 opacity-40"></i>
                <p class="text-sm">Belum ada riwayat pengisian.</p>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/kuisioner/index.blade.php ENDPATH**/ ?>