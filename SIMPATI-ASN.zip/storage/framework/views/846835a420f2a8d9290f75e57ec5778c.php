<?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if (isset($component)) { $__componentOriginalbb23e9ac5a36d29b8233754d5dbca1be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb23e9ac5a36d29b8233754d5dbca1be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.data-stat-card','data' => ['icon' => $stat['icon'],'color' => $stat['color'],'label' => $stat['label'],'value' => $stat['value'],'unit' => $stat['unit'],'subtitle' => $stat['subtitle']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('data-stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['icon']),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['color']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['label']),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['value']),'unit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['unit']),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['subtitle'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb23e9ac5a36d29b8233754d5dbca1be)): ?>
<?php $attributes = $__attributesOriginalbb23e9ac5a36d29b8233754d5dbca1be; ?>
<?php unset($__attributesOriginalbb23e9ac5a36d29b8233754d5dbca1be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb23e9ac5a36d29b8233754d5dbca1be)): ?>
<?php $component = $__componentOriginalbb23e9ac5a36d29b8233754d5dbca1be; ?>
<?php unset($__componentOriginalbb23e9ac5a36d29b8233754d5dbca1be); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Administrator\Documents\BRIN\Project Apps\SIMPATI-ASN\resources\views/data/partials/stat-cards.blade.php ENDPATH**/ ?>